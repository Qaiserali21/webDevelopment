<footer>
		<!-- <div class="container clearfix">
			<ul>
				<li><a href="index.html" class="animated_link active">Multiple Branch</a></li>
				<li><a href="index-2.html" class="animated_link">Single Branch</a></li>
				<li><a href="index-3.html" class="animated_link">Without Branch</a></li>
				<li><a href="index-4.html" class="animated_link">Images Version</a></li>
				<li><a href="index-5.html" class="animated_link">Multiple Branch + FileUpload</a></li>
				<li><a href="#0" class="animated_link"><strong>Purchase this Template</strong></a></li>
			</ul>
			<p>© 2023 Steps</p>
		</div> -->
	</footer>
	<!-- /footer -->
	
	<div class="cd-overlay-nav">
		<span></span>
	</div>
	<!-- /cd-overlay-nav -->

	<div class="cd-overlay-content">
		<span></span>
	</div>
	<!-- /cd-overlay-content -->

	<a href="#0" class="cd-nav-trigger">Menu<span class="cd-icon"></span></a>
	<!-- /cd-nav-trigger -->
	
	<!-- Modal terms -->
	<div class="modal fade" id="terms-txt" tabindex="-1" role="dialog" aria-labelledby="termsLabel" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="termsLabel">Terms and conditions</h5>
					<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
				</div>
				<div class="modal-body">
					<p>Lorem ipsum dolor sit amet, in porro albucius qui, in <strong>nec quod novum accumsan</strong>, mei ludus tamquam dolores id. No sit debitis meliore postulant, per ex prompta alterum sanctus, pro ne quod dicunt sensibus.</p>
					<p>Lorem ipsum dolor sit amet, in porro albucius qui, in nec quod novum accumsan, mei ludus tamquam dolores id. No sit debitis meliore postulant, per ex prompta alterum sanctus, pro ne quod dicunt sensibus. Lorem ipsum dolor sit amet, <strong>in porro albucius qui</strong>, in nec quod novum accumsan, mei ludus tamquam dolores id. No sit debitis meliore postulant, per ex prompta alterum sanctus, pro ne quod dicunt sensibus.</p>
					<p>Lorem ipsum dolor sit amet, in porro albucius qui, in nec quod novum accumsan, mei ludus tamquam dolores id. No sit debitis meliore postulant, per ex prompta alterum sanctus, pro ne quod dicunt sensibus.</p>
				</div>
			</div>
		</div>
	</div>
	<!-- /Modal terms -->
	
	<!-- COMMON SCRIPTS -->
    <!-- <script src="js/jquery-3.7.1.min.js"></script> -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js" ></script>
	<script src="js/common_scripts.min.js"></script>

	<script src="js/menu.js"></script>
	<script src="js/main.js"></script>
	<script src="js/wizard_func_multiple_branch.js"></script>	
	
</body>
</html>
<!-- fffff -->